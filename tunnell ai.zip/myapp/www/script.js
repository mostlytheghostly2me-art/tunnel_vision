// =========================================================
// Danilo soco | ghost
// Ghost watermark – do not remove
// =========================================================

// --- Text-to-Speech ---
function speak(text) {
  speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = "en-US";
  speechSynthesis.speak(utter);
}

// --- Speech-to-Text ---
function startListening() {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Rec) {
    alert("Speech recognition not supported in this browser.");
    return;
  }

  const rec = new Rec();
  rec.lang = "en-US";
  document.getElementById("output").innerText = "🎤 Listening...";

  rec.onresult = (e) => {
    const userSpeech = e.results[0][0].transcript;
    document.getElementById("output").innerText =
      "You said: " + userSpeech;
    speak("You said: " + userSpeech);
  };

  rec.onerror = () => {
    document.getElementById("output").innerText =
      "❌ I couldn't hear you.";
  };

  rec.start();
}

// =========================================================
// Danilo soco | ghost
// End watermark
// =========================================================
